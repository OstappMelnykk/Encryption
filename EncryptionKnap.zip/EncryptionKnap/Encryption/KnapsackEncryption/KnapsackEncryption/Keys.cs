﻿namespace WebApplication_Gamma
{
    public static class Keys
    {
        public const string FirstFilePathKey = "FirstFilePath";
        public const string NewFilePathKey = "NewFilePath";

    }
}
