﻿namespace EncryptionWebApplication.Models
{
    public class Class
    {
    }
}
